Prerequisites for this project

- use Python 3.8 or 3.9


1) install ovencv (version 4.5), please you this and install opencv.

           -pip install opencv-python

2) install mediapipe (version 0.8.5), please you this and install mediapipe.

           -pip install mediapipe==0.8.5

3) install tensorflow (version 2.5.0), please you this and install tensorflow.

	   -pip install tensorflow==2.5.0

Step to Run "face_and_hand_rec(from_camera).py" this code.
In this method i am taking images from laptop camera and detecting face, thumbs up and thumbs down.

1) Open face_and_hand_rec(from_camera).py
2) In line number 11 please give path of "gesture.name".
3) In line number 13 please give path of "mp_hand_gesture" folder.
4) you can test this data with diffrent thershold.
5)it will show you live results just make sure that your face or thumb up, thumb down is there in front of camera. 

Step to Run "face_and_hand_rec(from_saved_images).py" this code.
In this method i used images from internet and store the output images and count of faces, thumbs up and thumbs down. 

1) Please delete "output" folder
2) Open face_and_hand_rec(from_saved_images).py
3) In line number 11 give folder path of folder which include images of faces, thumbs up and thumbs down.
4) In line number 12 please give path of "gesture.name".
5) In line number 13 please give path of "mp_hand_gesture" folder.
6) you can test this data with diffrent thershold.