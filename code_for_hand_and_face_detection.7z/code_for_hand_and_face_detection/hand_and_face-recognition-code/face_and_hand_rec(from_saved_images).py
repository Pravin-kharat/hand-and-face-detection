import cv2
import os
import mediapipe as mp
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
mp_face_detection = mp.solutions.face_detection
mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands
# For static images:
IMAGE_FILES = 'C:\\Users\\biju\\Desktop\\codes\\hand_and_face-recognition-code\\data\\'              #
class_name ='C:\\Users\\biju\\Desktop\\codes\\hand_and_face-recognition-code\\gesture.names'
model = 'C:\\Users\\biju\\Desktop\\codes\\hand_and_face-recognition-code\\mp_hand_gesture'
thershold = 0.5

model = load_model(model)
f = open(class_name, 'r')
classNames = f.read().split('\n')
f.close()
print(classNames)
sub_path = IMAGE_FILES.split("\\")[-2]
path = IMAGE_FILES.rstrip(sub_path+"\\")
output_add = path + '/' + 'output'
try:
  os.makedirs(output_add)
  print('created output path')
except FileExistsError:
  print('output path already exists')
f = open(output_add+'/'+"Count.txt", "w+")
for file in os.listdir(IMAGE_FILES):
  num_faces = []
  thumb_up = []
  thumb_down = []
  image = cv2.imread(os.path.join(IMAGE_FILES, file))
  # Convert the BGR image to RGB and process it with MediaPipe Face Detection.
  with mp_face_detection.FaceDetection(
          min_detection_confidence=thershold) as face_detection:
    results = face_detection.process(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    # Draw face detections of each face.
    annotated_image = image.copy()
    if not results.detections:
      annotated_image = image.copy()
    else:
      for detection in results.detections:
        num_faces.append(detection.label_id)
        mp_drawing.draw_detection(annotated_image, detection)
    with mp_hands.Hands(
            static_image_mode=True,
            max_num_hands=4,
            min_detection_confidence=thershold) as hands:
      image = cv2.flip(annotated_image, 1)
      # Convert the BGR image to RGB before processing.
      results = hands.process(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
      image_height, image_width, _ = image.shape
      annotated_image1 = image.copy()
      if not results.multi_hand_landmarks:
        cv2.imwrite(output_add + '/' + str(file) + '.png', annotated_image)
      else:
        landmarks = []
        for hand_landmarks in results.multi_hand_landmarks:
          for lm in hand_landmarks.landmark:
            lmx = int(lm.x * image_width)
            lmy = int(lm.y * image_height)
            landmarks.append([lmx, lmy])
          #print(list(mp_hands.HAND_CONNECTIONS)[0])
          mp_drawing.draw_landmarks(
            annotated_image1, hand_landmarks, mp_hands.HAND_CONNECTIONS)
          cv2.imwrite(output_add + '/' + str(file) + '.png', annotated_image1)
          if len(landmarks) == 21:
            prediction = model.predict([landmarks])
            classID = np.argmax(prediction)
            className = classNames[classID]
            if className == "thumbs up":
              thumb_up.append(1)
            elif className == "thumbs down":
              thumb_down.append(1)
          else:
            for i in range(0, len(landmarks), 21):
              land = list(landmarks[i:i + 21])
              prediction = model.predict([land])
              classID = np.argmax(prediction)
              className = list(classNames[classID])
              if className == "thumbs up":
                thumb_up.append(1)
              elif className == "thumbs down":
                thumb_down.append(1)
  f.write('Image_name : {}, number_of_faces : {}, thumbs_up : {}, thumbs_down: {}'.format(
              file, len(num_faces), len(thumb_up), len(thumb_down)))
  f.write("\n")