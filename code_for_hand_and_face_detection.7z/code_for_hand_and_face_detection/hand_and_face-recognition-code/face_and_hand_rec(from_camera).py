import cv2
import os
import mediapipe as mp
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
mp_face_detection = mp.solutions.face_detection
mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands

class_name ='C:\\Users\\biju\\Desktop\\app\pip\\hand-gesture-recognition-code\\gesture.names'
model = 'C:\\Users\\biju\\Desktop\\app\pip\\hand-gesture-recognition-code\\mp_hand_gesture'
thershold = 0.5
def detector(class_name, model, thershold):
  model = load_model(model)
  f = open(class_name, 'r')
  classNames = f.read().split('\n')
  f.close()
  vidcap = cv2.VideoCapture(0)
  success = True
  while success:
    success, image = vidcap.read()
    image = cv2.flip(image, 1)
    num_faces = []
    # Convert the BGR image to RGB and process it with MediaPipe Face Detection.
    with mp_face_detection.FaceDetection(
            min_detection_confidence=thershold) as face_detection:
      results = face_detection.process(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
      # Draw face detections of each face.
      annotated_image = image.copy()
      if not results.detections:
        annotated_image = image.copy()
      else:
        for detection in results.detections:
          num_faces.append(detection.label_id)
          mp_drawing.draw_detection(annotated_image, detection)
          img = cv2.putText(annotated_image, f"Number of Faces :{len(num_faces)}", (10, 20), 2, 0.8, (0, 255, 255), 2)
          #img = cv2.putText(img, f"Number of thumb_up :{len(thumb_up)}", (10, 50), 2, 0.8, (0, 255, 255), 2)
          #img = cv2.putText(img, f"Number of thumb_up :{len(thumb_down)}", (10, 80), 2, 0.8, (0, 255, 255), 2)
          cv2.imshow("face", img)
          if cv2.waitKey(1) == ord('q'):
            break
      with mp_hands.Hands(
              static_image_mode=True,
              max_num_hands=4,
              min_detection_confidence=thershold) as hands:
        # Convert the BGR image to RGB before processing.
        results = hands.process(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        image_height, image_width, _ = image.shape
        annotated_image1 = annotated_image.copy()
        if not results.multi_hand_landmarks:
          continue
          #cv2.imwrite(output_add + '/' + str() + '.png', annotated_image)
        else:
          landmarks = []
          for hand_landmarks in results.multi_hand_landmarks:
            for lm in hand_landmarks.landmark:
              lmx = int(lm.x * image_width)
              lmy = int(lm.y * image_height)
              landmarks.append([lmx, lmy])
            mp_drawing.draw_landmarks(
              annotated_image1, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            thumb_up=[]
            thumb_down=[]
            if len(landmarks) == 21:
              prediction = model.predict([landmarks])
              classID = np.argmax(prediction)
              className = classNames[classID]
              if className == "thumbs up":
                thumb_up.append(className)
              elif className == "thumbs down":
                thumb_down.append(className)
            else:
              for i in range(0, len(landmarks), 21):
                land = list(landmarks[i:i + 21])
                prediction = model.predict([land])
                classID = np.argmax(prediction)
                className = classNames[classID]
                if className == "thumbs up":
                  thumb_up.append(className)
                elif className == "thumbs down":
                  thumb_down.append(className)
              print(thumb_up)
            imh = cv2.putText(annotated_image1, f"Number of Faces :{len(num_faces)}", (10, 20), 2, 0.8, (0, 255, 255), 2)
            imh = cv2.putText(imh, f"Number of thumb_up :{len(thumb_up)}", (10, 50), 2, 0.8, (0, 255, 255), 2)
            imh = cv2.putText(imh, f"Number of thumb_down :{len(thumb_down)}", (10, 80), 2, 0.8, (0, 255, 255), 2)
            cv2.imshow("face_and_hand", imh)
            if cv2.waitKey(1) == ord('q'):
              break
detector(class_name, model, thershold)